window.YTD.tweets.part0 = [
 {"tweet":{"id_str":"111","created_at":"Mon Mar 04 10:00:00 +0000 2024","full_text":"tune https://t.co/x","entities":{"urls":[{"url":"https://t.co/x","expanded_url":"https://open.spotify.com/track/4uLU6hMCjMI75M1A2tKUQC"}]}}},
 {"tweet":{"id_str":"112","created_at":"Tue Mar 05 10:00:00 +0000 2024","full_text":"video https://t.co/y","entities":{"urls":[{"url":"https://t.co/y","expanded_url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ"}]}}}
]